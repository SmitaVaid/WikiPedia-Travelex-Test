package wiki;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by smita on 07/05/2016.
 */
public abstract class BrowserFactory {
    public static WebDriver driver;

    public static WebDriver StartBrowser(String Browser){
        try
        {
        if (Browser.equalsIgnoreCase("Firefox")) {
            driver = new FirefoxDriver();
        }
           /* else if(Browser.equalsIgnoreCase("chrome"))
            {

                System.setProperty("webdriver.chrome.driver", "/Users/smita/Downloads/chromedriver");
                driver=new ChromeDriver();
            }*/

        else
            throw new RuntimeException("Browser give "+Browser+ " did not load..");
        }
        catch(Exception e)
        {
            throw new RuntimeException("Browser give "+Browser+ " did not load..");
        }

        return driver;
    }

    public static WebDriver getDriver()
    {
        return driver;
    }

}