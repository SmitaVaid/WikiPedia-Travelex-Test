package wiki;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 07/05/2016.
 */
public class Utils {
     static WebDriver driver = BrowserFactory.getDriver();

    public static void sleep(int i) {
        try {
            Thread.sleep(i*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static boolean isElementPresent(By element)
    {
        try
        {
            return driver.findElement(element).isDisplayed();

        }
        catch (Exception e)
        {
            return false;
        }
    }

    public static boolean isTextPresent(String text)
    {
        return getVisibleText().contains(text);
    }

    public static String getVisibleText()
    {
        driver = BrowserFactory.getDriver();
        return driver.findElement(By.tagName("body")).getText();
    }
}
