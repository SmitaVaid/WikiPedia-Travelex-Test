package wiki;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 07/05/2016.
 */
public class HomePage {
    WebDriver driver = BrowserFactory.getDriver();

    public void verifyTitle() {
        Assert.assertTrue("WikipediA", true);
    }

    public void SearchItem(String searchItem) {
        driver.findElement(By.id("searchInput")).sendKeys(searchItem);

    }

    public void NavigateToSearchResultPage() {
        driver.findElement(By.xpath("html/body/div[2]/form/fieldset/button")).click();
        Assert.assertTrue("Search results", true);

    }
}
